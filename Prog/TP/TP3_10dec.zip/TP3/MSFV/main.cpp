#include "MSFV.h"
#include "CelluleListe.h"
#include "ListDCwCur.h"
#include "Fichier.h"
#include "Dossier.h"
#include "CelluleFile.h"
#include "FileCirc.h"
#include "NoeudArbreBinaire.h"
#include "ArbreAVL.h"
#include "Procedure_Baker.h"

/* --------------------------------------------------------------------------------------
 *   Variables globales
 * ----------------------------------------------------------------------------------- */

CMSFVTextBox* dlgNom;	// Bo�te de dialogue pour la saisie de nom.
CMSFVMemo* dlgTexte;	// Bo�te de dialogue pour la saisie de contenu de fichier texte.
CMenu* mnuContextuel;	// Menu contextuel.
CDossier* pRacine = new CDossier(nullptr, new CListDCwCur<CDossier*>(), new CListDCwCur<CFichier*>(), "Racine");	//pointeur vers le dossier racine
CDossier* pCurrent = pRacine; //pointeur du dossier courant
CArbreAVL<CDossier*>* pArbreDossierSelect = new CArbreAVL<CDossier*>();	//pointeur vers un arbre des dossiers selectionners
CArbreAVL<CFichier*>* pArbreFichierSelect = new CArbreAVL<CFichier*>();	//pointeur vers un arbre des fichiers selectionners


/* --------------------------------------------------------------------------------------
 *   �v�nement ex�cut� au d�marrage du programme.
 * ----------------------------------------------------------------------------------- */

void OnShow(void) {


}

/* --------------------------------------------------------------------------------------
 *   �v�nement ex�cut� lors d'un click avec la souris souris.
 * --------------------------------------------------------------------------------------
 *         _iX : Position du click sur l'axe des X.
 *         _iY : Position du click sur l'axe des Y.
 *   _ucBouton : Bouton utilis� pour clicker (BOUTON_GAUCHE, BOUTON_DROITE).
 *     _boCTRL : Si la touche Ctrl du clavier est enfonc�e.
 * ----------------------------------------------------------------------------------- */

void OnMouseClick(int _iX, int _iY, unsigned char _ucBouton, bool _boCTRL) {
	int iMenuVal = MENU_AUCUN;
	string strNom;		//contient le nom a mettre dans le dossier/fichier
	string strContent;	//contient le contenu du showDialog pour les mettre dans le dossier/fichier
	bool boSameName = false; //verifie si le nouveau fichier ou dossier a le meme nom qu'un autre dans le meme dossier
	int iIndX, iIndY, iIndSelect;	//sert a calculer l'indice du dossier/fichier qui a ete clicker

	iIndX = ((_iX * (FENETRE_LARGEUR / ICONE_LARGEUR)) / (FENETRE_LARGEUR)+1);
	iIndY = ((_iY * (FENETRE_HAUTEUR / ICONE_HAUTEUR)) / (FENETRE_HAUTEUR));
	iIndSelect = iIndX + (iIndY * (FENETRE_LARGEUR / ICONE_LARGEUR));

	if (_ucBouton == BOUTON_GAUCHE && (!boCTRL))
	{
		//verifie si le click n'est pas dans le vide
		if (iIndSelect <= (pCurrent->ObtenirListeDossier()->ObtenirCompte() + pCurrent->ObtenirListeFichier()->ObtenirCompte()) + 1)
		{
			if ((pCurrent == pRacine))
			{
				//si c'est un dossier
				if (iIndSelect <= pCurrent->ObtenirListeDossier()->ObtenirCompte())
				{
					pCurrent->ObtenirListeFichier()->AllerA(iIndSelect);
					pCurrent = pCurrent->ObtenirListeDossier()->Obtenir();
				}
				//si c'est un Fichier
				else if (iIndSelect > pCurrent->ObtenirListeDossier()->ObtenirCompte())
				{
					pCurrent->ObtenirListeFichier()->AllerA(iIndSelect - pCurrent->ObtenirListeDossier()->ObtenirCompte());
					CFichier* pfichier = pCurrent->ObtenirListeFichier()->Obtenir();	//point vers le meme fichier sans avoir a reecrir tout la ligne
					dlgTexte->SetTitle(pfichier->ObtenirNom());
					dlgTexte->SetText(pfichier->ObtenirContent());
					strContent = dlgTexte->ShowDialog();
					pfichier->DefinirContent(strContent);
				}
			}
			else
			{
				//si c'est un dossier
				if (iIndSelect == 1)
					pCurrent = pCurrent->ObtenirParent();
				//si c'est un Fichier
				else if (iIndSelect > pCurrent->ObtenirListeDossier()->ObtenirCompte())
				{
					pCurrent->ObtenirListeFichier()->AllerA(iIndSelect - pCurrent->ObtenirListeDossier()->ObtenirCompte() - 1);
					CFichier* pfichier = pCurrent->ObtenirListeFichier()->Obtenir();	//point vers le meme fichier sans avoir a reecrir tout la ligne
					dlgTexte->SetTitle(pfichier->ObtenirNom());
					dlgTexte->SetText(pfichier->ObtenirContent());
					strContent = dlgTexte->ShowDialog();
					pfichier->DefinirContent(strContent);
				}
			}
		}
	}
	if ((_ucBouton == BOUTON_GAUCHE) && (_boCTRL))
	{
		//verifie si le click n'est pas dans le vide
		if (iIndSelect <= (pCurrent->ObtenirListeDossier()->ObtenirCompte() + pCurrent->ObtenirListeFichier()->ObtenirCompte()))
		{
			if (pCurrent == pRacine)
			{
				//si c'est un dossier
				if (iIndSelect <= pCurrent->ObtenirListeDossier()->ObtenirCompte())
				{
					pCurrent->ObtenirListeDossier()->AllerA(iIndSelect);
					pArbreDossierSelect->Ajouter(pCurrent->ObtenirListeDossier()->Obtenir());
				}
				//si c'est un Fichier
				if (iIndSelect > pCurrent->ObtenirListeDossier()->ObtenirCompte())
				{
					pCurrent->ObtenirListeFichier()->AllerA(iIndSelect - pCurrent->ObtenirListeDossier()->ObtenirCompte());
					pArbreFichierSelect->Ajouter(pCurrent->ObtenirListeFichier()->Obtenir());
				}
			}
		}
	}
	else if (_ucBouton == BOUTON_DROITE)
	{
		if (((pCurrent == pRacine) && iIndSelect <=
			(pCurrent->ObtenirListeDossier()->ObtenirCompte() + pCurrent->ObtenirListeFichier()->ObtenirCompte())) ||
			((pCurrent != pRacine) && iIndSelect <=
			(pCurrent->ObtenirListeDossier()->ObtenirCompte() + pCurrent->ObtenirListeFichier()->ObtenirCompte()) + 1))
		{
			iMenuVal = mnuContextuel->ShowDialog(_iX, _iY, MENU_RENOMMER | MENU_SUPPRIMER);//valeur du menu(click droit) selectionner	
		}
		else if (pCurrent != pRacine && iIndSelect == 1)
		{
			iMenuVal = mnuContextuel->ShowDialog(_iX, _iY, MENU_AUCUN);
		}
		else
		{
			iMenuVal = mnuContextuel->ShowDialog(_iX, _iY, MENU_NOUVEAU_DOSSIER | MENU_NOUVEAU_FICHIER | MENU_SELECTIONNER_TOUT);
		}

		switch (iMenuVal)
		{
		case MENU_NOUVEAU_DOSSIER:
		{
			dlgNom->SetTitle("Nouveau dossier");
			dlgNom->SetText("Nouveau Dossier");
			strNom = dlgNom->ShowDialog();

			int ii = 0;
			int iNbDossier = pCurrent->ObtenirListeDossier()->ObtenirCompte();
			//boucle pour verifier si un autre dossier a le meme nom dans le dossier
			while ((ii < iNbDossier) && (!boSameName))
			{
				pCurrent->ObtenirListeDossier()->AllerA(ii);
				boSameName = pCurrent->ObtenirListeDossier()->Obtenir()->ObtenirNom() == strNom;
				ii++;
			}

			if ((strNom != "") && (!boSameName))
				pCurrent->ObtenirListeDossier()->Ajouter(new CDossier(pCurrent, new CListDCwCur<CDossier*>(), new CListDCwCur<CFichier*>(), strNom));

			//QuickSortDossier(1, pCurrent->ObtenirListeDossier()->ObtenirCompte(), pCurrent->ObtenirListeDossier());
			break;
		}
		case MENU_NOUVEAU_FICHIER:
		{
			dlgNom->SetText("Nouveau Fichier");
			dlgNom->SetTitle("Nouveau Fichier");
			strNom = dlgNom->ShowDialog();

			int ii = 0;
			int iNbFichier = pCurrent->ObtenirListeFichier()->ObtenirCompte();
			//boucle pour verifier si un autre fichier a le meme nom dans le dossier
			while ((ii < iNbFichier) && (!boSameName))
			{
				pCurrent->ObtenirListeFichier()->AllerA(ii);
				boSameName = pCurrent->ObtenirListeFichier()->Obtenir()->ObtenirNom() == strNom;
				ii++;
			}
			if ((strNom != "") && (!boSameName))
				pCurrent->ObtenirListeFichier()->Ajouter(new CFichier(strNom, string()));
			break;
		}
		case MENU_RENOMMER:
		{
			//si dossier
			if (iIndSelect <= pCurrent->ObtenirListeDossier()->ObtenirCompte())
			{
				pCurrent->ObtenirListeDossier()->AllerA(iIndSelect - pCurrent->ObtenirListeDossier()->ObtenirCompte());
				dlgNom->SetTitle("Renommer");
				dlgNom->SetText(pCurrent->ObtenirListeDossier()->Obtenir()->ObtenirNom());
				pCurrent->ObtenirListeDossier()->Obtenir()->DefinirNom(dlgNom->ShowDialog());
			}
			//si c'est un Fichier
			if (iIndSelect > pCurrent->ObtenirListeDossier()->ObtenirCompte())
			{
				pCurrent->ObtenirListeFichier()->AllerA(iIndSelect - pCurrent->ObtenirListeDossier()->ObtenirCompte());
				dlgNom->SetTitle("Renommer");
				dlgNom->SetText(pCurrent->ObtenirListeFichier()->Obtenir()->ObtenirNom());
				pCurrent->ObtenirListeFichier()->Obtenir()->DefinirNom(dlgNom->ShowDialog());
			}
			break;
		}
			//			case MENU_SUPPRIMER:
			//			{
			//			
			//				break;
			//			}
			//			case MENU_COMPRESSER:
			//			{
			//			
			//				break;
			//			}
			//			case MENU_DECOMPRESSER:
			//			{
			//			
			//				break;
			//			}
		case MENU_SELECTIONNER_TOUT:
		{

			pCurrent->ObtenirListeDossier()->AllerPremier();
			pCurrent->ObtenirListeFichier()->AllerPremier();
			for (int ii = 1; ii <= pCurrent->ObtenirListeDossier()->ObtenirCompte(); ii++)
			{
				pArbreDossierSelect->Ajouter(pCurrent->ObtenirListeDossier()->Obtenir());
				pCurrent->ObtenirListeDossier()->AllerSuivant();
			}
			for (int ii = 1; ii <= pCurrent->ObtenirListeFichier()->ObtenirCompte(); ii++)
			{
				pArbreFichierSelect->Ajouter(pCurrent->ObtenirListeFichier()->Obtenir());
				pCurrent->ObtenirListeFichier()->AllerSuivant();
			}
			break;
		}
		}
	}
}

/* --------------------------------------------------------------------------------------
 *   �v�nement ex�cut� lors de l'affichage.
 * ----------------------------------------------------------------------------------- */

void OnRefresh(void){
	//DessinerBarreEtat(1, 0);
	int iNbIconRow = (iLargeurFenetre - ICONE_LARGEUR) / ICONE_LARGEUR;	//calcule le nombre d'icon qui entre par ligne
	int iHauteur = 0;	//sert a calculer la hauteur afin de mettre les icons dans la bonne ranger
	int iRow = 0;	//sert a calculer le nombre de pixel en X et aligner les icon dans la meme ranger

	if (pCurrent != pRacine)
	{
		DessinerIcone(iRow, iHauteur, ICONE_DOSSIER, 0);
		DessinerChaine("..", iRow + (ICONE_LARGEUR / 2) - (LargeurChaine("..") / 2), iHauteur + ICONE_HAUTEUR);
		iRow = 1;
	}

	pCurrent->ObtenirListeDossier()->AllerPremier();
	pCurrent->ObtenirListeFichier()->AllerPremier();

	for (int ii = 0; ii < pCurrent->ObtenirListeDossier()->ObtenirCompte(); ii++)
	{
		DessinerIcone(iRow * ICONE_LARGEUR, iHauteur, ICONE_DOSSIER, pArbreDossierSelect->Rechercher(pCurrent->ObtenirListeDossier()->Obtenir()));

		int iXNomCentrer = iRow * ICONE_LARGEUR + ((ICONE_LARGEUR / 2) - (LargeurChaine(pCurrent->ObtenirListeDossier()->Obtenir()->ObtenirNom().c_str()) / 2));	//la coordonne en X du nom pour qu'il soit centrer
		if (LargeurChaine(pCurrent->ObtenirListeDossier()->Obtenir()->ObtenirNom().c_str()) <= ICONE_LARGEUR)
			DessinerChaine(pCurrent->ObtenirListeDossier()->Obtenir()->ObtenirNom().c_str(), iXNomCentrer, iHauteur + ICONE_HAUTEUR);
		else
		{
			string strShortName = pCurrent->ObtenirListeDossier()->Obtenir()->ObtenirNom().substr(0, 7) + "...";
			iXNomCentrer = iRow * ICONE_LARGEUR + ((ICONE_LARGEUR / 2) - (LargeurChaine(strShortName.c_str()) / 2));	//la coordonne en X du nom pour qu'il soit centrer
			DessinerChaine(strShortName.c_str(), iXNomCentrer, iHauteur + ICONE_HAUTEUR);
		}

		if (iRow < iNbIconRow)
			iRow++;
		else
		{
			iRow = 0;
			iHauteur += ICONE_HAUTEUR + 15;
		}

		pCurrent->ObtenirListeDossier()->AllerSuivant();
	}
	for (int ii = 0; ii < pCurrent->ObtenirListeFichier()->ObtenirCompte(); ii++)
	{
		DessinerIcone(iRow * ICONE_LARGEUR, iHauteur, ICONE_FICHIER, pArbreFichierSelect->Rechercher(pCurrent->ObtenirListeFichier()->Obtenir()));

		int iXNomCentrer = iRow * ICONE_LARGEUR + ((ICONE_LARGEUR / 2) - (LargeurChaine(pCurrent->ObtenirListeFichier()->Obtenir()->ObtenirNom().c_str()) / 2));	//la coordonne en X du nom pour qu'il soit centrer
		if (LargeurChaine(pCurrent->ObtenirListeFichier()->Obtenir()->ObtenirNom().c_str()) <= ICONE_LARGEUR)
			DessinerChaine(pCurrent->ObtenirListeFichier()->Obtenir()->ObtenirNom().c_str(), iXNomCentrer, iHauteur + ICONE_HAUTEUR);
		else
		{
			string strShortName = pCurrent->ObtenirListeFichier()->Obtenir()->ObtenirNom().substr(0, 7) + "...";
			iXNomCentrer = iRow * ICONE_LARGEUR + ((ICONE_LARGEUR / 2) - (LargeurChaine(strShortName.c_str()) / 2));
			DessinerChaine(strShortName.c_str(), iXNomCentrer, iHauteur + ICONE_HAUTEUR);
		}

		if (iRow < iNbIconRow)
			iRow++;
		else
		{
			iRow = 0;
			iHauteur += ICONE_HAUTEUR + 15;
		}

		pCurrent->ObtenirListeFichier()->AllerSuivant();
	}
}

/* --------------------------------------------------------------------------------------
 *   �v�nement ex�cut� � la fermeture du programme.
 * ----------------------------------------------------------------------------------- */

void OnClose(void) {
	ofstream File;
	File.open("Micro.sam");
	File << pCurrent;
	File.close();

}

/* --------------------------------------------------------------------------------------
 *   Fonction principale du programme.
 * --------------------------------------------------------------------------------------
 *      _NbrParams : Nombre de param�tres pass�s au programme.
 *   _tabstrParams : Tableau de cha�ne de caract�res des param�tres pass�s au programme.
 *          return : Code de fin du programme.
 * ----------------------------------------------------------------------------------- */


int main(int _NbrParams, char* _tabstrParams[]) {
	// Initialisation...
	Init(1024, 768);
	dlgNom = new CMSFVTextBox(pSDLRenderer);
	dlgTexte = new CMSFVMemo(pSDLRenderer);
	mnuContextuel = new CMenu();

	// Ex�cution...
	OnShow();
	while (Execution());
	OnClose();

	// Conclusion...
	delete mnuContextuel;
	delete dlgTexte;
	delete dlgNom;

	//	delete pArbreDossierSelect;
	//	delete pArbreFichierSelect;
	//	delete pRacine;
	//	delete pCurrent;

	return 0;
}


/* ------------------------------------ NOTE -------------------------------------
 *	DOSSIER: debut du contenu dossier
 *	REISSOD: fin du contenu dossier
 *	FICHIER: debut du contenu du fichier
 *	REIHCIF: fin du contenu du fichier
 *	HUFFMAN: compression
 *	NAMFFUH: decompression
 * -----------------------------------------------------------------------------*/