#define ICONE_LARGEUR 93
#define ICONE_HAUTEUR 98

//IMPORTANT NE PAS OUBLIE DE CHANGER LE PATH VERS LE PROJET REMIS------------------------
//IMPORTANT NE PAS OUBLIE DE CHANGER LE PATH VERS LE PROJET REMIS------------------------
//IMPORTANT NE PAS OUBLIE DE CHANGER LE PATH VERS LE PROJET REMIS------------------------
//IMPORTANT NE PAS OUBLIE DE CHANGER LE PATH VERS LE PROJET REMIS------------------------

#define CHEMIN_IMAGE_DOSSIER "P:\\Prog\\TP\\MSFV\\Debug\\dossier.bmp"
#define CHEMIN_IMAGE_DOSSIER_SELECTIONNE "P:\\Prog\\TP\\MSFV\\Debug\\_dossier.bmp"
#define CHEMIN_IMAGE_FICHIER "P:\\Prog\\TP\\MSFV\\Debug\\fichier.bmp"
#define CHEMIN_IMAGE_FICHIER_SELECTIONNE "P:\\Prog\\TP\\MSFV\\Debug\\_fichier.bmp"
#define CHEMIN_IMAGE_COMPRESSE "P:\\Prog\\TP\\MSFV\\Debug\\compresse.bmp"
#define CHEMIN_IMAGE_COMPRESSE_SELECTIONNE "P:\\Prog\\TP\\MSFV\\Debug\\_compresse.bmp"
#define CHEMIN_POLICE_CARACTERES "P:\\Prog\\TP\\MSFV\\Debug\\arial.ttf"
#define CHEMIN_POLICE_CARACTERES_TITRE "P:\\Prog\\TP\\MSFV\\Debug\\arialbd.ttf"