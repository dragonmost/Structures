#include "MSFV.h"
#include "CelluleListe.h"
#include "ListDCwCur.h"
#include "Fichier.h"
#include "Dossier.h"

#define LARGEUR_ICON 93
#define HAUTEUR_ICON 98

/* --------------------------------------------------------------------------------------
 *   Variables globales
 * ----------------------------------------------------------------------------------- */

CMSFVTextBox* dlgNom;	// Bo�te de dialogue pour la saisie de nom.
CMSFVMemo* dlgTexte;	// Bo�te de dialogue pour la saisie de contenu de fichier texte.
CMenu* mnuContextuel;	// Menu contextuel.
CDossier* pRacine = new CDossier(nullptr, new CListDCwCur<CDossier*>(), new CListDCwCur<CFichier*>(), "Racine");	//pointeur vers le dossier racine
CDossier* pCurrent = pRacine; //pointeur du dossier courant


/* --------------------------------------------------------------------------------------
 *   �v�nement ex�cut� au d�marrage du programme.
 * ----------------------------------------------------------------------------------- */

void OnShow(void) {


}

/* --------------------------------------------------------------------------------------
 *   �v�nement ex�cut� lors d'un click avec la souris souris.
 * --------------------------------------------------------------------------------------
 *         _iX : Position du click sur l'axe des X.
 *         _iY : Position du click sur l'axe des Y.
 *   _ucBouton : Bouton utilis� pour clicker (BOUTON_GAUCHE, BOUTON_DROITE).
 *     _boCTRL : Si la touche Ctrl du clavier est enfonc�e.
 * ----------------------------------------------------------------------------------- */

void OnMouseClick(int _iX, int _iY, unsigned char _ucBouton, bool _boCTRL) {
	string strNom;
	bool boSameName = false; //verifie si le nouveau fichier ou dossier a le meme nom qu'un autre dans le meme dossier
	if (_ucBouton == BOUTON_DROITE)
	{
		int iMenuVal = mnuContextuel->ShowDialog(_iX, _iY, MENU_NOUVEAU_DOSSIER | MENU_NOUVEAU_FICHIER);//valeur du menu(click droit) selectionner	
		switch (iMenuVal)
		{
		case MENU_NOUVEAU_DOSSIER:
		{
			dlgNom->SetTitle("Nouveau dossier");
			dlgNom->SetText("Nouveau Dossier");
			strNom = dlgNom->ShowDialog();

			int ii = 0;
			int iNbDossier = pCurrent->ObtenirListeDossier()->ObtenirCompte();
			while ((ii < iNbDossier) && (!boSameName))
			{
				pCurrent->ObtenirListeDossier()->AllerA(ii);
				boSameName = pCurrent->ObtenirListeDossier()->Obtenir()->ObtenirNom() == strNom;
				ii++;
			}

			if ((strNom != "") && (!boSameName))
				pCurrent->ObtenirListeDossier()->Ajouter(new CDossier(pCurrent, new CListDCwCur<CDossier*>(), new CListDCwCur<CFichier*>(), strNom));
			break;
		}
		case MENU_NOUVEAU_FICHIER:
		{
			dlgNom->SetText("Nouveau Fichier");
			dlgNom->SetTitle("Nouveau Fichier");
			strNom = dlgNom->ShowDialog();

			int ii = 0;
			int iNbFichier = pCurrent->ObtenirListeFichier()->ObtenirCompte();
			while ((ii < iNbFichier) && (!boSameName))
			{
				pCurrent->ObtenirListeFichier()->AllerA(ii);
				boSameName = pCurrent->ObtenirListeFichier()->Obtenir()->ObtenirNom() == strNom;
				ii++;
			}
			if ((strNom != "") && (!boSameName))
				pCurrent->ObtenirListeFichier()->Ajouter(new CFichier(strNom, ""));
			break;
		}
			//case MENU_RENOMMER:
			//{
			//
			//	break;
			//case MENU_SUPPRIMER:
			//{
			//
			//	break;
			//}
			//case MENU_COMPRESSER:
			//{
			//
			//	break;
			//}
			//case MENU_DECOMPRESSER:
			//{
			//
			//	break;
			//}
			//case MENU_SELECTIONNER_TOUT:
			//{
			//
			//	break;
			//}
			//}
		}
	}
	//dlgNom->SetTitle("ok");
	//dlgNom->SetText("lol noob");
	//dlgNom->ShowDialog();
}

/* --------------------------------------------------------------------------------------
 *   �v�nement ex�cut� lors de l'affichage.
 * ----------------------------------------------------------------------------------- */

void OnRefresh(void){
	//DessinerIcone(7, 7, ICONE_DOSSIER, 0);
	//DessinerChaine("twitch.tv/", 7, 100);
	//int taille = LargeurChaine("twitch.tv/");
	//
	//DessinerTitre("Twitch.tv/dragonmost1");
	//DessinerBarreEtat(1, 0);
	int iNbIconRow = (iLargeurFenetre - LARGEUR_ICON) / LARGEUR_ICON;
	int iRow = 0;
	int iHauteur = 0;
	for (int ii = 0; ii < pCurrent->ObtenirListeDossier()->ObtenirCompte(); ii++)
	{
		pCurrent->ObtenirListeDossier()->AllerA(ii + 1);

		DessinerIcone(iRow * LARGEUR_ICON, iHauteur, ICONE_DOSSIER, 0);

		if (LargeurChaine(pCurrent->ObtenirListeDossier()->Obtenir()->ObtenirNom().c_str()) <= LARGEUR_ICON)
			DessinerChaine(pCurrent->ObtenirListeDossier()->Obtenir()->ObtenirNom().c_str(), iRow * (LARGEUR_ICON), iHauteur + HAUTEUR_ICON);
		else
		{
			string strShortName = pCurrent->ObtenirListeDossier()->Obtenir()->ObtenirNom().substr(0,7) + "...";
			DessinerChaine(strShortName.c_str(), iRow * (LARGEUR_ICON), iHauteur + HAUTEUR_ICON);
		}

		if (iRow < iNbIconRow)
			iRow++;
		else
		{
			iRow = 0;
			iHauteur += HAUTEUR_ICON + 15;
		}
	}
	for (int ii = 0; ii < pCurrent->ObtenirListeFichier()->ObtenirCompte(); ii++)
	{
		pCurrent->ObtenirListeFichier()->AllerA(ii + 1);

		DessinerIcone(iRow * LARGEUR_ICON, iHauteur, ICONE_FICHIER, 0);

		if (LargeurChaine(pCurrent->ObtenirListeFichier()->Obtenir()->ObtenirNom().c_str()) <= LARGEUR_ICON)
			DessinerChaine(pCurrent->ObtenirListeFichier()->Obtenir()->ObtenirNom().c_str(), iRow * (LARGEUR_ICON), iHauteur + HAUTEUR_ICON);
		else
		{
			string strShortName = pCurrent->ObtenirListeFichier()->Obtenir()->ObtenirNom().substr(0, 7) + "...";
			DessinerChaine(strShortName.c_str(), iRow * (LARGEUR_ICON), iHauteur + HAUTEUR_ICON);
		}

		if (iRow < iNbIconRow)
			iRow++;
		else
		{
			iRow = 0;
			iHauteur += HAUTEUR_ICON + 15;
		}
	}
}

/* --------------------------------------------------------------------------------------
 *   �v�nement ex�cut� � la fermeture du programme.
 * ----------------------------------------------------------------------------------- */

void OnClose(void) {
}

/* --------------------------------------------------------------------------------------
 *   Fonction principale du programme.
 * --------------------------------------------------------------------------------------
 *      _NbrParams : Nombre de param�tres pass�s au programme.
 *   _tabstrParams : Tableau de cha�ne de caract�res des param�tres pass�s au programme.
 *          return : Code de fin du programme.
 * ----------------------------------------------------------------------------------- */

int main(int _NbrParams, char* _tabstrParams[]) {
	// Initialisation...
	Init(1024, 768);
	dlgNom = new CMSFVTextBox(pSDLRenderer);
	dlgTexte = new CMSFVMemo(pSDLRenderer);
	mnuContextuel = new CMenu();

	// Ex�cution...
	OnShow();
	while (Execution());
	OnClose();

	// Conclusion...
	delete mnuContextuel;
	delete dlgTexte;
	delete dlgNom;
	return 0;
}


/* ------------------------------------ NOTE -------------------------------------
 *	DOSSIER: debut du contenu dossier
 *	REISSOD: fin du contenu dossier
 *	FICHIER: debut du contenu du fichier
 *	REIHCIF: fin du contenu du fichier
 *	HUFFMAN: compression
 *	NAMFFUH: decompression
 * -----------------------------------------------------------------------------*/